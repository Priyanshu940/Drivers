#!/system/bin/sh

if [ "$(id -u)" != "0" ]; then
  echo "Error: Please run as root." 1>&2
  exit 1
fi

ERROR_MSG=$(insmod ./5.10.ko 2>&1)
if [ $? -eq 0 ]; then
  echo "Driver module loaded successfully."
  exit 0
else
  echo "Failed to load driver module: $ERROR_MSG"
  exit 1
fi
